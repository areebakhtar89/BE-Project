package com.example.chintan.myapplication.Data;

public class selectrange {
    public static  double  range;

    public static double getRange() {
        return range;
    }

    public static void setRange(double range) {
        selectrange.range = range;
    }
}
