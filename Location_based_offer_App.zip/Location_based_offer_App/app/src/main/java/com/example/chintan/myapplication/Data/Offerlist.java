package com.example.chintan.myapplication.Data;

import java.util.ArrayList;

public class Offerlist {
    public static ArrayList<String> offerid,offername,offerprice,offerdescription,offerstartdate,offerlastdate,image,v_vendorid,v_name,v_lat,v_log;

    public static ArrayList<Double> information_dist;

    public static ArrayList<Double> getInformation_dist() {
        return information_dist;
    }

    public static void setInformation_dist(ArrayList<Double> information_dist) {
        Offerlist.information_dist = information_dist;
    }

    public static ArrayList<String> getV_vendorid() {
        return v_vendorid;
    }

    public static void setV_vendorid(ArrayList<String> v_vendorid) {
        Offerlist.v_vendorid = v_vendorid;
    }

    public static ArrayList<String> getV_name() {
        return v_name;
    }

    public static void setV_name(ArrayList<String> v_name) {
        Offerlist.v_name = v_name;
    }

    public static ArrayList<String> getV_lat() {
        return v_lat;
    }

    public static void setV_lat(ArrayList<String> v_lat) {
        Offerlist.v_lat = v_lat;
    }

    public static ArrayList<String> getV_log() {
        return v_log;
    }

    public static void setV_log(ArrayList<String> v_log) {
        Offerlist.v_log = v_log;
    }

    public static ArrayList<String> getOfferid() {
        return offerid;
    }

    public static void setOfferid(ArrayList<String> offerid) {
        Offerlist.offerid = offerid;
    }

    public static ArrayList<String> getOffername() {
        return offername;
    }

    public static void setOffername(ArrayList<String> offername) {
        Offerlist.offername = offername;
    }

    public static ArrayList<String> getOfferprice() {
        return offerprice;
    }

    public static void setOfferprice(ArrayList<String> offerprice) {
        Offerlist.offerprice = offerprice;
    }

    public static ArrayList<String> getOfferdescription() {
        return offerdescription;
    }

    public static void setOfferdescription(ArrayList<String> offerdescription) {
        Offerlist.offerdescription = offerdescription;
    }

    public static ArrayList<String> getOfferstartdate() {
        return offerstartdate;
    }

    public static void setOfferstartdate(ArrayList<String> offerstartdate) {
        Offerlist.offerstartdate = offerstartdate;
    }

    public static ArrayList<String> getOfferlastdate() {
        return offerlastdate;
    }

    public static void setOfferlastdate(ArrayList<String> offerlastdate) {
        Offerlist.offerlastdate = offerlastdate;
    }

    public static ArrayList<String> getImage() {
        return image;
    }

    public static void setImage(ArrayList<String> image) {
        Offerlist.image = image;
    }






}
