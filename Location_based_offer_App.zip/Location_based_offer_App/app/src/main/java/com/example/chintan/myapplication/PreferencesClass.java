package com.example.chintan.myapplication;

public class PreferencesClass {
    public static final String loginPref = "loginPref";
}
