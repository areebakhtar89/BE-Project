package com.example.chintan.myapplication.Data;

import java.util.ArrayList;

public class Existingofferdata {

    public static ArrayList<String> eofferid,eoffername,eofferdescription;

    public static ArrayList<String> getEofferid() {
        return eofferid;
    }

    public static void setEofferid(ArrayList<String> eofferid) {
        Existingofferdata.eofferid = eofferid;
    }

    public static ArrayList<String> getEoffername() {
        return eoffername;
    }

    public static void setEoffername(ArrayList<String> eoffername) {
        Existingofferdata.eoffername = eoffername;
    }

    public static ArrayList<String> getEofferdescription() {
        return eofferdescription;
    }

    public static void setEofferdescription(ArrayList<String> eofferdescription) {
        Existingofferdata.eofferdescription = eofferdescription;
    }
}
