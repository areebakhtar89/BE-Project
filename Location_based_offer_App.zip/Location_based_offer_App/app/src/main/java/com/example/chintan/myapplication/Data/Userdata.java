package com.example.chintan.myapplication.Data;

public class Userdata {
    public static String userid,name,email,contact,address,password,repassword;

    public static String getUserid() {
        return userid;
    }

    public static void setUserid(String userid) {
        Userdata.userid = userid;
    }

    public static String getName() {
        return name;
    }

    public static void setName(String name) {
        Userdata.name = name;
    }

    public static String getEmail() {
        return email;
    }

    public static void setEmail(String email) {
        Userdata.email = email;
    }

    public static String getContact() {
        return contact;
    }

    public static void setContact(String contact) {
        Userdata.contact = contact;
    }

    public static String getAddress() {
        return address;
    }

    public static void setAddress(String address) {
        Userdata.address = address;
    }

    public static String getPassword() {
        return password;
    }

    public static void setPassword(String password) {
        Userdata.password = password;
    }

    public static String getRepassword() {
        return repassword;
    }

    public static void setRepassword(String repassword) {
        Userdata.repassword = repassword;
    }
}
