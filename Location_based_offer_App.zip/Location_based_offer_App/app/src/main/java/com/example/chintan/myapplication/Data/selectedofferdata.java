package com.example.chintan.myapplication.Data;

public class selectedofferdata {
    public static String selofferid,seloffername,selofferprice,selofferaddress,selofferdescription,selofferstartdate,selofferlastdate,selimage,sellat,sellong,selvid;

    public static String getSellat() {
        return sellat;
    }

    public static void setSellat(String sellat) {
        selectedofferdata.sellat = sellat;
    }

    public static String getSellong() {
        return sellong;
    }

    public static void setSellong(String sellong) {
        selectedofferdata.sellong = sellong;
    }

    public static String getSelofferaddress() {
        return selofferaddress;
    }

    public static void setSelofferaddress(String selofferaddress) {
        selectedofferdata.selofferaddress = selofferaddress;
    }

    public static String getSelvid() {
        return selvid;
    }

    public static void setSelvid(String selvid) {
        selectedofferdata.selvid = selvid;
    }

    public static String getSelofferid() {
        return selofferid;
    }

    public static void setSelofferid(String selofferid) {
        selectedofferdata.selofferid = selofferid;
    }

    public static String getSeloffername() {
        return seloffername;
    }

    public static void setSeloffername(String seloffername) {
        selectedofferdata.seloffername = seloffername;
    }

    public static String getSelofferprice() {
        return selofferprice;
    }

    public static void setSelofferprice(String selofferprice) {
        selectedofferdata.selofferprice = selofferprice;
    }

    public static String getSelofferdescription() {
        return selofferdescription;
    }

    public static void setSelofferdescription(String selofferdescription) {
        selectedofferdata.selofferdescription = selofferdescription;
    }

    public static String getSelofferstartdate() {
        return selofferstartdate;
    }

    public static void setSelofferstartdate(String selofferstartdate) {
        selectedofferdata.selofferstartdate = selofferstartdate;
    }

    public static String getSelofferlastdate() {
        return selofferlastdate;
    }

    public static void setSelofferlastdate(String selofferlastdate) {
        selectedofferdata.selofferlastdate = selofferlastdate;
    }

    public static String getSelimage() {
        return selimage;
    }

    public static void setSelimage(String selimage) {
        selectedofferdata.selimage = selimage;
    }
}
