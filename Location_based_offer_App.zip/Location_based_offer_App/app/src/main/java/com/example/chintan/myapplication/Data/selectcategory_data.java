package com.example.chintan.myapplication.Data;

public class selectcategory_data {
    public static String vendor_id,v_name,v_location,v_contact,v_description,v_lat,v_lon,cat_id,oldrate;

    public static int rate;

    public static String getOldrate() {
        return oldrate;
    }

    public static void setOldrate(String oldrate) {
        selectcategory_data.oldrate = oldrate;
    }

    public static String getVendor_id() {

        return vendor_id;
    }

    public static void setVendor_id(String vendor_id) {
        selectcategory_data.vendor_id = vendor_id;
    }

    public static String getV_name() {
        return v_name;
    }

    public static void setV_name(String v_name) {
        selectcategory_data.v_name = v_name;
    }

    public static String getV_location() {
        return v_location;
    }

    public static void setV_location(String v_location) {
        selectcategory_data.v_location = v_location;
    }

    public static String getV_contact() {
        return v_contact;
    }

    public static void setV_contact(String v_contact) {
        selectcategory_data.v_contact = v_contact;
    }

    public static String getV_description() {
        return v_description;
    }

    public static void setV_description(String v_description) {
        selectcategory_data.v_description = v_description;
    }

    public static String getV_lat() {
        return v_lat;
    }

    public static void setV_lat(String v_lat) {
        selectcategory_data.v_lat = v_lat;
    }

    public static String getV_lon() {
        return v_lon;
    }

    public static void setV_lon(String v_lon) {
        selectcategory_data.v_lon = v_lon;
    }

    public static String getCat_id() {
        return cat_id;
    }

    public static void setCat_id(String cat_id) {
        selectcategory_data.cat_id = cat_id;
    }

    public static int getRate() {
        return rate;
    }

    public static void setRate(int rate) {
        selectcategory_data.rate = rate;
    }
}
