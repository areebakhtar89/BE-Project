package com.example.chintan.myapplication.Data;

public class Location_ {
    public static Double latitude,longitude;

    public static Double getLatitude() {
        return latitude;
    }

    public static void setLatitude(Double latitude) {
        Location_.latitude = latitude;
    }

    public static Double getLongitude() {
        return longitude;
    }

    public static void setLongitude(Double longitude) {
        Location_.longitude = longitude;
    }
}
