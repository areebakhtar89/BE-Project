package com.example.chintan.myapplication.Data;

import java.util.ArrayList;

public class Selectedexistingofferdata {
    public static String sel_eofferid,sel_eoffername,sel_eofferdescription;


    public static String getSel_eofferid() {
        return sel_eofferid;
    }

    public static void setSel_eofferid(String sel_eofferid) {
        Selectedexistingofferdata.sel_eofferid = sel_eofferid;
    }

    public static String getSel_eoffername() {
        return sel_eoffername;
    }

    public static void setSel_eoffername(String sel_eoffername) {
        Selectedexistingofferdata.sel_eoffername = sel_eoffername;
    }

    public static String getSel_eofferdescription() {
        return sel_eofferdescription;
    }

    public static void setSel_eofferdescription(String sel_eofferdescription) {
        Selectedexistingofferdata.sel_eofferdescription = sel_eofferdescription;
    }
}
