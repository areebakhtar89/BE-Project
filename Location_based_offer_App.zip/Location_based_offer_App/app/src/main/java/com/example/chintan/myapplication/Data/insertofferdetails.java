package com.example.chintan.myapplication.Data;

public class insertofferdetails {

    public static String customer_id,offer_id,offername,offerdescription,vendor_id;

    public static String getCustomer_id() {
        return customer_id;
    }

    public static void setCustomer_id(String customer_id) {
        insertofferdetails.customer_id = customer_id;
    }

    public static String getVendor_id() {
        return vendor_id;
    }

    public static void setVendor_id(String vendor_id) {
        insertofferdetails.vendor_id = vendor_id;
    }

    public static String getOffer_id() {
        return offer_id;
    }

    public static void setOffer_id(String offer_id) {
        insertofferdetails.offer_id = offer_id;
    }

    public static String getOffername() {
        return offername;
    }

    public static void setOffername(String offername) {
        insertofferdetails.offername = offername;
    }

    public static String getOfferdescription() {
        return offerdescription;
    }

    public static void setOfferdescription(String offerdescription) {
        insertofferdetails.offerdescription = offerdescription;
    }
}
